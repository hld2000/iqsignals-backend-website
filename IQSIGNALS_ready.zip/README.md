IQSIGNALS - AI crypto copy-trade platform (mobile-ready ZIP)

This package is a starter scaffold. Follow README_mobile steps to deploy from phone.
