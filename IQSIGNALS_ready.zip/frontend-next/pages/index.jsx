import Link from 'next/link'
export default function Home(){ return (<div style={{padding:20}}><h1>IQSIGNALS</h1><p><Link href='/trade'>Trade</Link> | <Link href='/signals'>AI Signals</Link></p></div>) }
